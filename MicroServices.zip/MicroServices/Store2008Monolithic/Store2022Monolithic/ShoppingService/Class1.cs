﻿namespace ShoppingService
{
    public class Class1
    {

    }
}
