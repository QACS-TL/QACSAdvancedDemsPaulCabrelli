using Microsoft.AspNetCore.Mvc;
using Store2022Monolithic.Models;
using System.Diagnostics;
using ShoppingService;
using AccountService;
using InventoryService;

namespace Store2022Monolithic.Controllers
{

    public class HomeController : Controller
    {
        private static AccountSvc AccountServices = new AccountSvc();
        private static InventorySvc InventoryServices = new InventorySvc();
        private static ShoppingSvc ShoppingServices = new ShoppingSvc();

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var commercemodel = new CommerceModel()
            {
                User = AccountServices.GetConsumerById(1),
                Products = InventoryServices.GetProducts(),
                Cart = ShoppingServices.GetCart(30)
            };

            return View(commercemodel);
        }

        public ActionResult About()
        {
            var commercemodel = new CommerceModel()
            {
                User = AccountServices.GetConsumerById(1),
                Products = InventoryServices.GetProducts()
            };

            return View(commercemodel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
