using System;

namespace backend
{
    public class PizzaInfo
    {
        public string PizzaName { get; set; }

        public int Cost { get; set; }

        public string Ingredients { get; set; }

        public string InStock { get; set; }
    }
}