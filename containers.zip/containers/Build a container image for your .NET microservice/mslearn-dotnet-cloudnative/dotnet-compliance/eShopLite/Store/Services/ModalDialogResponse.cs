namespace Store;

public class ModalDialogResponse
{
    public bool Confirm {get; set;}
    public int Quantity {get; set;}
}