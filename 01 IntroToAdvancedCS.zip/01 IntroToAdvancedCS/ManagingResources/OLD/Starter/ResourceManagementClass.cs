using System;
using System.Drawing;

namespace ManagingResources 
{
	public class ResourceManagementClass 
	{
		IntPtr unmanagedResource;
		Brush   br;

		public ResourceManagementClass()
		{
			unmanagedResource = NativeResourceSimulator.CreateResource();
			br = new System.Drawing.Drawing2D.LinearGradientBrush( new Rectangle(0, 0, 100, 100), Color.Red, Color.Blue, Environment.TickCount % 360 );
		}

		public void Use() 
		{
			// use the brush and unmanaged resources
			// code not shown for clarity
		}

		// other implementation methods omitted for clarity
	
	}
}
