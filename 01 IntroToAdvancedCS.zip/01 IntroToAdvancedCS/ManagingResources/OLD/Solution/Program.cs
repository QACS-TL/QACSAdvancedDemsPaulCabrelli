using System;
using System.Windows.Forms;

namespace ManagingResources
{
	class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			System.Windows.Forms.Application.Run( new MainForm() );
		}
	}
}
