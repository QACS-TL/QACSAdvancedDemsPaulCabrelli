using System;

namespace ManagingResources
{
	/// <summary>
	/// Summary description for NativeResouceSimulator.
	/// </summary>
	public class NativeResourceSimulator
	{
		// Simulates allocating an unmanaged resource and returning a handle/pointer
		public static IntPtr CreateResource() {
			return new IntPtr( 12345 );
		}

		// Simulates releasing an unmanaged resource from the handle that's passed in
		public static void ReleaseResource( IntPtr p ) {
			if( p == IntPtr.Zero ) {
				throw new ArgumentOutOfRangeException( "p", IntPtr.Zero, "This shouldn't be called with a null pointer" );
			}
		}
	}
}
