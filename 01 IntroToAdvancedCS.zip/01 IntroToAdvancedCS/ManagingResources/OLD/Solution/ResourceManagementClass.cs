using System;
using System.Drawing;

namespace ManagingResources 
{
	public class ResourceManagementClass : IDisposable
	{
		IntPtr unmanagedResource;
		Brush  br;
		bool   isDisposed;

		public ResourceManagementClass()
		{
			unmanagedResource = NativeResourceSimulator.CreateResource();
			br = new System.Drawing.Drawing2D.LinearGradientBrush( new Rectangle(0, 0, 100, 100), Color.Red, Color.Blue, Environment.TickCount % 360 );
		}

		~ResourceManagementClass() {
			Dispose( false );
		}

		public void Dispose() 
		{
			Dispose( true );
		}

		protected virtual void Dispose( bool isDisposing ) 
		{
			if( !isDisposed ) 
			{
				if( isDisposing ) 
				{
					if( br != null ) 
					{
						br.Dispose();
					}
					System.GC.SuppressFinalize( this );
				}
				
				if( unmanagedResource != IntPtr.Zero ) 
				{
					NativeResourceSimulator.ReleaseResource( unmanagedResource );
					unmanagedResource = IntPtr.Zero;
				}
			}
			isDisposed = true;
		}

		public void Use() {
			if( isDisposed ) {
				throw new ObjectDisposedException( "ResourceManagementClass" );
			}
			// use the brush and unmanaged resources
			// code not shown for clarity
		}
	}
}
