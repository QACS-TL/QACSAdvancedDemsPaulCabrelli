using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ManagingResources
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnClickMe;
		private System.Windows.Forms.Button btnGC;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClickMe = new System.Windows.Forms.Button();
			this.btnGC = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnClickMe
			// 
			this.btnClickMe.Location = new System.Drawing.Point(24, 16);
			this.btnClickMe.Name = "btnClickMe";
			this.btnClickMe.Size = new System.Drawing.Size(136, 64);
			this.btnClickMe.TabIndex = 0;
			this.btnClickMe.Text = "Click Me!";
			this.btnClickMe.Click += new System.EventHandler(this.btnClickMe_Click);
			// 
			// btnGC
			// 
			this.btnGC.Location = new System.Drawing.Point(192, 40);
			this.btnGC.Name = "btnGC";
			this.btnGC.TabIndex = 1;
			this.btnGC.Text = "GC";
			this.btnGC.Click += new System.EventHandler(this.btnGC_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(280, 101);
			this.Controls.Add(this.btnGC);
			this.Controls.Add(this.btnClickMe);
			this.Name = "MainForm";
			this.Text = "MainForm";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnClickMe_Click(object sender, System.EventArgs e) {
			using( ResourceManagementClass rmc = new ResourceManagementClass() ) {
				rmc.Use();
			}
		}

		private void btnGC_Click(object sender, System.EventArgs e) {
			System.GC.Collect();
		}
	}
}
