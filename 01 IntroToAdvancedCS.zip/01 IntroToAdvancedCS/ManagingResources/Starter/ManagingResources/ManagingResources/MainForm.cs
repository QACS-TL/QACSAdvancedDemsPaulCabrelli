namespace ManagingResources
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
            ResourceManagementClass rmc = new ResourceManagementClass();
            rmc.Use();
        }

        private void btnGC_Click(object sender, EventArgs e)
        {
            System.GC.Collect();
        }
    }
}
