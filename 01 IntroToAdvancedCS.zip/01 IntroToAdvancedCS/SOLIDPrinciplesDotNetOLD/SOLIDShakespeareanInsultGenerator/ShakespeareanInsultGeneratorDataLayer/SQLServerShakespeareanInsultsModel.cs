namespace ShakespeareanInsultGeneratorDataLayer
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    partial class SQLServerShakespeareanInsultsModel : DbContext
    {
        public SQLServerShakespeareanInsultsModel()
            : base("name=ShakespeareanInsultsModel")
        {
        }

        public virtual DbSet<Insult> Insults { get; set; }
        public virtual DbSet<Phrase> Phrases { get; set; }

    }
}
