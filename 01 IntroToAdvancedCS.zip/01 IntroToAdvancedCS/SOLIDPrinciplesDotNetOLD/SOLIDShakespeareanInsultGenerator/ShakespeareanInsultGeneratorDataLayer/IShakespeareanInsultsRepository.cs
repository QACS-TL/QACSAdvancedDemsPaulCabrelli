﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShakespeareanInsultGeneratorDataLayer
{
    public interface IShakespeareanInsultsRepository
    {
        IEnumerable<Phrase> GetPhrases(int phrasePosition);
        IEnumerable<Phrase> GetPhrases(int phraseSet, string phraseText);
        IEnumerable<String> GetAllInsults();
        Insult GetInsult(int phrase1Id, int phrase2Id, int phrase3Id);
        void InsertInsult(Insult insult);
    }
}
