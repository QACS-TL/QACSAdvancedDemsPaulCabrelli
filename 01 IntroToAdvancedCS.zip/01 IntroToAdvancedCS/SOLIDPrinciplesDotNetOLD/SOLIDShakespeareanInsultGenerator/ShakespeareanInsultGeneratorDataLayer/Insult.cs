namespace ShakespeareanInsultGeneratorDataLayer
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Insult
    {

        internal Insult()
        {

        }

        public Insult(int phrase1id, int phrase2id, int phrase3id)
        {
            this.id = 0;
            this.phrase1id = phrase1id;
            this.phrase2id = phrase2id;
            this.phrase3id = phrase3id;
        }

        internal Insult(int id, int phrase1id, int phrase2id, int phrase3id)
        {
            this.id = id;
            this.phrase1id = phrase1id;
            this.phrase2id = phrase2id;
            this.phrase3id = phrase3id;
        }

        public int id { get; set; }

        public int phrase1id { get; set; }

        public int phrase2id { get; set; }

        public int phrase3id { get; set; }

    }
}
