namespace ShakespeareanInsultGeneratorDataLayer
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Phrases")]
    public partial class Phrase
    {
        public Phrase()
        {

        }

        public Phrase(int id, string phrase, int phrasePosition)
        {
            this.id = id;
            this.phrase = phrase;
            this.phrasePosition = phrasePosition;
        }

        public int id { get; set; }

        [Required]
        [StringLength(100)]
        public string phrase { get; set; }

        public int phrasePosition { get; set; }

        public override string ToString()
        {
            return phrase;
        }
    }
}
