﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ShakespeareanInsultGeneratorDataLayer
{
    class CSVShakespeareanInsultsModel
    {
        //Populates Insults and Phrases collections from existing file system files
        public virtual List<Insult> Insults { get; set; }
        public virtual List<Phrase> Phrases { get; set; }

        public CSVShakespeareanInsultsModel()
        {

            Insults = new List<Insult>();
            Phrases = new List<Phrase>();

            //Populate Phrases collection with the 3 sets of phrases
            FileStream stream1 = new FileStream("CSVPhrases1.txt", FileMode.Open, FileAccess.Read);
            FileStream stream2 = new FileStream("CSVPhrases2.txt", FileMode.Open, FileAccess.Read);
            FileStream stream3 = new FileStream("CSVPhrases3.txt", FileMode.Open, FileAccess.Read);
            string phrases;
            int phraseId = 1;

            using (StreamReader reader = new StreamReader(stream1))
            {
                phrases = reader.ReadToEnd();
            }

            //create array of phrases
            string[] phrasesArray = CleanPhrasesStringAndSplit(phrases);
 
            int phrasePosition = 1;
            for (int i = 0; i < phrasesArray.Count(); i++)
            {
                Phrases.Add(new Phrase(phraseId, phrasesArray[i], phrasePosition));
                phraseId++;
            }

            using (StreamReader reader = new StreamReader(stream2))
            {
                phrases = reader.ReadToEnd();
            }
            phrasesArray = CleanPhrasesStringAndSplit(phrases);
            phrasePosition = 2;
            for (int i = 0; i < phrasesArray.Count(); i++)
            {
                Phrases.Add(new Phrase(phraseId, phrasesArray[i], phrasePosition));
                phraseId++;
            }

            using (StreamReader reader = new StreamReader(stream3))
            {
                phrases = reader.ReadToEnd();
            }
            //Strip out 
            phrasesArray = CleanPhrasesStringAndSplit(phrases);
            phrasePosition = 3;
            for (int i = 0; i < phrasesArray.Count(); i++)
            {
                Phrases.Add(new Phrase(phraseId, phrasesArray[i], phrasePosition));
                phraseId++;
            }

            //Populate Insults Collection
            FileStream insultsStream = new FileStream("Insults.txt", FileMode.Open, FileAccess.Read);
            using (StreamReader reader = new StreamReader(insultsStream))
            {            
                string insultString = reader.ReadLine();
                int insultId = 1;
                while (!string.IsNullOrEmpty(insultString))
                {
                    insultString.Replace('"', '0');
                    string[] insultArray = insultString.Split(',');
                    Insult insult = new Insult(Convert.ToInt32(insultArray[0]), Convert.ToInt32(insultArray[1]), Convert.ToInt32(insultArray[2]), Convert.ToInt32(insultArray[3]));
                    Insults.Add(insult);

                    insultId++;
                    insultString = reader.ReadLine();
                }
            }
        }

        //CLEAN UP DATA, remove double quotes and split into string array separating on commas between phrases
        //keeping commas inside phrases
        private static String[] CleanPhrasesStringAndSplit(string phrases)
        {
            // replace commas inside double quotes with ~
            phrases = Regex.Replace(phrases, @",(?=[^""]*""(?:[^""]*""[^""]*"")*[^""]*$)", "~");
            //strip out all double quotes
            phrases = phrases.Replace("\"", "");
            //Strip out all spaces that trail commas
            phrases = Regex.Replace(phrases, @",[ ]*", ",");
            //Replace all commas with @
            phrases = phrases.Replace(",", "@");
            //Replace all ~ with commas
            phrases = phrases.Replace("~", ",");
            //create array of phrases splitting on @ (which were commas between phrases)
            return phrases.Split('@');
        }

        public void SaveChanges()
        {
            //Save changes is only called when a new insult has been added to collection so we only need
            //to append the latest insult to the external file
            FileStream insultsStream = new FileStream("Insults.txt", FileMode.Append, FileAccess.Write);
            using (StreamWriter writer = new StreamWriter(insultsStream))
            {
                Insult latestInsult = Insults[Insults.Count()-1];
                writer.WriteLine(string.Format("{0},{1},{2},{3}", latestInsult.id, latestInsult.phrase1id, latestInsult.phrase2id, latestInsult.phrase3id));
            }
        }


    }
}
