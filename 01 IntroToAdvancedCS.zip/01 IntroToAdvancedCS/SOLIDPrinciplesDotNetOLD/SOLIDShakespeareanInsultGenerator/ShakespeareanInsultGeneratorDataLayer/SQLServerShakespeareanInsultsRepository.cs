﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShakespeareanInsultGeneratorDataLayer
{
    public class SQLServerShakespeareanInsultsRepository: IShakespeareanInsultsRepository
    {
        SQLServerShakespeareanInsultsModel model = new SQLServerShakespeareanInsultsModel();

        IEnumerable<Phrase> IShakespeareanInsultsRepository.GetPhrases(int phraseSet)
        {
            return model.Phrases.Where(p => p.phrasePosition == phraseSet);
        }

        IEnumerable<Phrase> IShakespeareanInsultsRepository.GetPhrases(int phraseSet, string phraseText)
        {
            string phraseFirstLetter = phraseText.Substring(0, 1);
            return model.Phrases.Where(p => p.phrasePosition == phraseSet && p.phrase.StartsWith(phraseFirstLetter));
        }

        IEnumerable<string> IShakespeareanInsultsRepository.GetAllInsults()
        {
            List<string> insults = new List<string>();
            foreach (Insult insult in model.Insults)
            {
                string phrase1 = model.Phrases.SingleOrDefault(p => p.id == insult.phrase1id).phrase;
                string phrase2 = model.Phrases.SingleOrDefault(p => p.id == insult.phrase2id).phrase;
                string phrase3 = model.Phrases.SingleOrDefault(p => p.id == insult.phrase3id).phrase;
                StringBuilder insultAsString = new StringBuilder();
                insults.Add(String.Format("{0} {1} {2}", phrase1, phrase2, phrase3));
            }
            return insults;
        }

        void IShakespeareanInsultsRepository.InsertInsult(Insult insult)
        {
            model.Insults.Add(insult);
            model.SaveChanges();
        }



        Insult IShakespeareanInsultsRepository.GetInsult(int phrase1Id, int phrase2Id, int phrase3Id)
        {
            return model.Insults.SingleOrDefault(i => i.phrase1id == phrase1Id && i.phrase2id == phrase2Id && i.phrase3id == phrase3Id);

        }
    }
}
