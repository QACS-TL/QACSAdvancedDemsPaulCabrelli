﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShakespeareanInsultGeneratorDataLayer;

namespace SOLIDShakespeareanInsultGenerator
{
    class ShakespeareanInsultsViewModel
    {
        IShakespeareanInsultsRepository repository = null;

        public ShakespeareanInsultsViewModel():this(new SQLServerShakespeareanInsultsRepository())
        {

        }

        public ShakespeareanInsultsViewModel(IShakespeareanInsultsRepository repository)
        {
            this.repository = repository;
        }

        public IEnumerable<Phrase> GetPhrases(int phrasePosition)
        {
            return repository.GetPhrases(phrasePosition);
        }

        public IEnumerable<Phrase> GetPhrases(int phrasePosition, string phrasetext)
        {
            return repository.GetPhrases(phrasePosition, phrasetext);
        }

        public IEnumerable<string> GetAllInsults()
        {
            return repository.GetAllInsults().OrderBy(i => i);
        }

        public void InsertInsult(Insult insult)
        {

            repository.InsertInsult(insult);
        }

        public Insult GetInsult(int phrase1Id, int phrase2Id, int phrase3Id)
        {
            return repository.GetInsult(phrase1Id, phrase2Id, phrase3Id);
        }

    }
}
