﻿using ShakespeareanInsultGeneratorDataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SOLIDShakespeareanInsultGenerator
{
    public partial class MainForm : Form
    {
        ShakespeareanInsultsViewModel model = null;

        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            model = new ShakespeareanInsultsViewModel(new CSVShakespeareanInsultsRepository());
            lstPhrase1.DataSource = model.GetPhrases(1).ToList();

            lstInsults.DataSource = model.GetAllInsults().ToList();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstPhrase1_Click(object sender, EventArgs e)
        {
            Phrase phrase = (Phrase)lstPhrase1.SelectedItem;
            lstPhrase2.DataSource = model.GetPhrases(2, phrase.phrase).ToList();
            //clear third listbox
            lstPhrase3.DataSource = null;
            //force deselection of second listbox 
            lstPhrase2.SelectedIndex = -1;
        }

        private void lstPhrase2_Click(object sender, EventArgs e)
        {
            Phrase phrase = (Phrase)lstPhrase2.SelectedItem;
            lstPhrase3.DataSource = model.GetPhrases(3, phrase.phrase).ToList();
            //force deselection of third listbox 
            lstPhrase3.SelectedIndex = -1;
        }

        private void lstPhrase3_Click(object sender, EventArgs e)
        {
            if (lstPhrase3.SelectedIndex >= 0)
            {
                btnAdd.Enabled = true;
            }
        }

        private void lstPhrase2_Enter(object sender, EventArgs e)
        {
            btnAdd.Enabled = false;

        }

        private void lstPhrase1_Enter(object sender, EventArgs e)
        {
            btnAdd.Enabled = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //int offSet = model.GetPhrases(1).Count();
            int insultId1 = ((Phrase)lstPhrase1.SelectedItem).id;
            int insultId2 = ((Phrase)lstPhrase2.SelectedItem).id;
            int insultId3 = ((Phrase)lstPhrase3.SelectedItem).id;

            //check for duplicate
            if (model.GetInsult(insultId1, insultId2, insultId3) == null)
            {
                Insult insult = new Insult(insultId1, insultId2, insultId3);
                model.InsertInsult(insult);
                lstInsults.DataSource = model.GetAllInsults().ToList();
            }
            else
            {
                MessageBox.Show("Duplicate Insult! \nInsult not added");
            }

        }
    }
}
