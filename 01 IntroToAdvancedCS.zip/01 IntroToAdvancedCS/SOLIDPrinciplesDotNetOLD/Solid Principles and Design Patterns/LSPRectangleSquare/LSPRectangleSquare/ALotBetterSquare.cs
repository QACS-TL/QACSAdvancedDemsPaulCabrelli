﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSPRectangleSquare
{
    public class ALotBetterSquare: IALotBetterQuadrilateral
    {
        private double lengthOfSide;

        public ALotBetterSquare(double lengthOfSide)
        {
            this.lengthOfSide = lengthOfSide;
        }

        public double Height
        {
            get
            {
                return lengthOfSide;
            }
        }

        public double Width
        {
            get
            {
                return lengthOfSide;
            }
        }


        public double Area
        {
            get
            {
                return Height * Width;
            }
        }
    }
}
