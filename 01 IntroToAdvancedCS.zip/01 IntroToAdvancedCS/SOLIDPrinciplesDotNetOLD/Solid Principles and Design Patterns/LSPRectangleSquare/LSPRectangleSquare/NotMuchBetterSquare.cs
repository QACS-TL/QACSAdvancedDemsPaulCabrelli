﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSPRectangleSquare
{
    public class NotMuchBetterSquare: INotMuchBetterQuadrilateral
    {
        private double width;
        private double height;

        public double Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
                width = value;
            }
        }

        public double Width
        {
            get
            {
                return width;
            }
            set
            {
                height = value; 
                width = value;
            }
        }


        public double Area
        {
            get
            {
                return height * width;
            }
        }
    }
}
