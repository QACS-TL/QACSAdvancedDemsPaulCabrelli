using System;

namespace LSPRectangleSquare
{
    public interface INotMuchBetterQuadrilateral
    {
         double Width
        {
            get;
            set;
        }

         double Height
        {
            get;
            set;
        }

        double Area
        {
            get;
        }
        
    }
}
