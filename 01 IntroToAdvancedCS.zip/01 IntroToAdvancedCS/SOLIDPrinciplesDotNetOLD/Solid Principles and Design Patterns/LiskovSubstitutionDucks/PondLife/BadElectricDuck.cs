﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PondLife
{
    public class BadElectricDuck:IDuck
    {
        private bool isTurnedOn = false;

        private bool isSwimming;
        public bool IsSwimming 
        { 
            get 
            { 
                return isSwimming; 
            } 
        }

        public void TurnOn()
        {
            isTurnedOn = true;
        }

        public void TurnOff()
        {
            isTurnedOn = false;
        }

        public void Swim()
        {
            if (!isTurnedOn)
            return;

            isSwimming = true;
            //swim logic  
        }

        public void Waddle()
        {
            if (!isTurnedOn)
                return;

            isSwimming = false;
            //waddle logic  
        }

        public void Fly()
        {
            if (!isTurnedOn)
                return;

            isSwimming = false;
            //fly logic  
        }
    }
}
