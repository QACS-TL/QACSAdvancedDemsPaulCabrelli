﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PondLife
{
    public class GoodElectricDuck: IDuck
    {
        public bool isTurnedOn = false;

        private bool isSwimming;
        public bool IsSwimming
        {
            get
            {
                return isSwimming;
            }
        }

        public void TurnOn()
        {
            isTurnedOn = true;
        }

        public void TurnOff()
        {
            isTurnedOn = false;
        }

        public void Swim()
        {
            this.TurnOn();

            isSwimming = true;
            //swim logic  
        }

        public void Waddle()
        {
            this.TurnOn();

            isSwimming = false;
            //waddle logic  
        }

        public void Fly()
        {
            this.TurnOn();

            isSwimming = false;
            //fly logic  
        }
    }
}
