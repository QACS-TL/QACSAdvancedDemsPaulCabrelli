﻿namespace LiskovSubstitutionDucks
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOrganicDuck = new System.Windows.Forms.Button();
            this.btnBadElectricDuck = new System.Windows.Forms.Button();
            this.btnGoodElectricDuck = new System.Windows.Forms.Button();
            this.btnEnhancedGoodElectricDuck = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOrganicDuck
            // 
            this.btnOrganicDuck.Location = new System.Drawing.Point(13, 25);
            this.btnOrganicDuck.Name = "btnOrganicDuck";
            this.btnOrganicDuck.Size = new System.Drawing.Size(109, 23);
            this.btnOrganicDuck.TabIndex = 0;
            this.btnOrganicDuck.Text = "Organic Duck";
            this.btnOrganicDuck.UseVisualStyleBackColor = true;
            this.btnOrganicDuck.Click += new System.EventHandler(this.btnOrganicDuck_Click);
            // 
            // btnBadElectricDuck
            // 
            this.btnBadElectricDuck.Location = new System.Drawing.Point(13, 55);
            this.btnBadElectricDuck.Name = "btnBadElectricDuck";
            this.btnBadElectricDuck.Size = new System.Drawing.Size(109, 23);
            this.btnBadElectricDuck.TabIndex = 1;
            this.btnBadElectricDuck.Text = "Bad Electric Duck";
            this.btnBadElectricDuck.UseVisualStyleBackColor = true;
            this.btnBadElectricDuck.Click += new System.EventHandler(this.btnBadElectricDuck_Click);
            // 
            // btnGoodElectricDuck
            // 
            this.btnGoodElectricDuck.Location = new System.Drawing.Point(13, 85);
            this.btnGoodElectricDuck.Name = "btnGoodElectricDuck";
            this.btnGoodElectricDuck.Size = new System.Drawing.Size(109, 23);
            this.btnGoodElectricDuck.TabIndex = 2;
            this.btnGoodElectricDuck.Text = "Good Electric Duck";
            this.btnGoodElectricDuck.UseVisualStyleBackColor = true;
            this.btnGoodElectricDuck.Click += new System.EventHandler(this.btnGoodElectricDuck_Click);
            // 
            // btnEnhancedGoodElectricDuck
            // 
            this.btnEnhancedGoodElectricDuck.Location = new System.Drawing.Point(13, 115);
            this.btnEnhancedGoodElectricDuck.Name = "btnEnhancedGoodElectricDuck";
            this.btnEnhancedGoodElectricDuck.Size = new System.Drawing.Size(109, 38);
            this.btnEnhancedGoodElectricDuck.TabIndex = 3;
            this.btnEnhancedGoodElectricDuck.Text = "Enhanced Good Electric Duck";
            this.btnEnhancedGoodElectricDuck.UseVisualStyleBackColor = true;
            this.btnEnhancedGoodElectricDuck.Click += new System.EventHandler(this.btnEnhancedGoodElectricDuck_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 264);
            this.Controls.Add(this.btnEnhancedGoodElectricDuck);
            this.Controls.Add(this.btnGoodElectricDuck);
            this.Controls.Add(this.btnBadElectricDuck);
            this.Controls.Add(this.btnOrganicDuck);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOrganicDuck;
        private System.Windows.Forms.Button btnBadElectricDuck;
        private System.Windows.Forms.Button btnGoodElectricDuck;
        private System.Windows.Forms.Button btnEnhancedGoodElectricDuck;
    }
}

