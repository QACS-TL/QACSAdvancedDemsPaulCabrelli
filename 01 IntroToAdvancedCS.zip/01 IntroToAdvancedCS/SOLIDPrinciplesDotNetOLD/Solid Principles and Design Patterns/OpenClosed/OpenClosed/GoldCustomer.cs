namespace OpenClosedPrinciple
{
    public class GoldCustomer : B_GoodCustomer {
        public override double GetDiscountedPrice(double TotalSales)
        {
            return TotalSales - 10 * TotalSales / 100;
        }
    }
}