﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuilderPattern
{
    //CarType enum
    public enum CarType
    {
        Saloon,
        Estate,
        SUV,
        Sports
    }
}
